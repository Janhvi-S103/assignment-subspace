export type Article = {
  id: string;
  title: string;
  summary: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  source: string;
  url?: string;
  date: string;
  isRead: boolean;
  isSaved: boolean;
};

export type NewsPreference = {
  id: string;
  category: string;
  isEnabled: boolean;
};

export type UserPreferences = {
  categories: NewsPreference[];
  darkMode: boolean;
};