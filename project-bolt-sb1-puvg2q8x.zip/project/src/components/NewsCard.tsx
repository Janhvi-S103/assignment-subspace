import React from 'react';
import { Bookmark, Share2, CheckCircle, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import type { Article } from '../types';

interface NewsCardProps {
  article: Article;
  onToggleRead: (id: string) => void;
  onToggleSave: (id: string) => void;
  onShare: (id: string) => void;
}

export function NewsCard({ article, onToggleRead, onToggleSave, onShare }: NewsCardProps) {
  const sentimentIcon = {
    positive: <TrendingUp className="w-5 h-5 text-green-500" />,
    negative: <TrendingDown className="w-5 h-5 text-red-500" />,
    neutral: <Minus className="w-5 h-5 text-gray-500" />
  }[article.sentiment];

  return (
    <div className={`bg-white rounded-lg shadow-md p-6 transition-all ${
      article.isRead ? 'opacity-75' : ''
    }`}>
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-xl font-semibold flex-1">{article.title}</h3>
        <div className="flex items-center gap-2">
          {sentimentIcon}
        </div>
      </div>
      
      <p className="text-gray-600 mb-4">{article.summary}</p>
      
      <div className="flex justify-between items-center text-sm text-gray-500">
        <div className="flex items-center gap-4">
          <span>{article.source}</span>
          <span>{article.date}</span>
        </div>
        
        <div className="flex gap-3">
          <button
            onClick={() => onToggleRead(article.id)}
            className={`p-2 rounded-full hover:bg-gray-100 transition-colors ${
              article.isRead ? 'text-blue-500' : 'text-gray-400'
            }`}
          >
            <CheckCircle className="w-5 h-5" />
          </button>
          
          <button
            onClick={() => onToggleSave(article.id)}
            className={`p-2 rounded-full hover:bg-gray-100 transition-colors ${
              article.isSaved ? 'text-yellow-500' : 'text-gray-400'
            }`}
          >
            <Bookmark className="w-5 h-5" />
          </button>
          
          <button
            onClick={() => onShare(article.id)}
            className="p-2 rounded-full hover:bg-gray-100 transition-colors text-gray-400"
          >
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}