import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Settings, LogOut, Newspaper, BookmarkPlus, Share2, CheckCircle, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import supabase from '../lib/supabase';
import type { Article, NewsPreference } from '../types';

interface DashboardProps {
  session: any; // Replace with proper session type
}

export function Dashboard({ session }: DashboardProps) {
  const navigate = useNavigate();
  const [preferences, setPreferences] = useState<NewsPreference[]>([]);
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showPreferences, setShowPreferences] = useState(false);

  useEffect(() => {
    fetchUserPreferences();
    fetchNewsArticles();
  }, []);

  const fetchUserPreferences = async () => {
    try {
      const { data, error } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', session.user.id)
        .single();

      if (error) throw error;
      setPreferences(data?.preferences || []);
    } catch (err) {
      console.error('Error fetching preferences:', err);
      setError('Failed to load preferences');
    }
  };

  const fetchNewsArticles = async () => {
    try {
      const { data, error } = await supabase
        .from('articles')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setArticles(data || []);
    } catch (err) {
      console.error('Error fetching articles:', err);
      setError('Failed to load articles');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePreferences = async (updatedPreferences: NewsPreference[]) => {
    try {
      const { error } = await supabase
        .from('user_preferences')
        .upsert({
          user_id: session.user.id,
          preferences: updatedPreferences,
        });

      if (error) throw error;
      setPreferences(updatedPreferences);
      setShowPreferences(false);
    } catch (err) {
      console.error('Error updating preferences:', err);
      setError('Failed to update preferences');
    }
  };

  const handleSignOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      navigate('/login');
    } catch (err) {
      console.error('Error signing out:', err);
      setError('Failed to sign out');
    }
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return <TrendingUp className="w-5 h-5 text-green-500" />;
      case 'negative':
        return <TrendingDown className="w-5 h-5 text-red-500" />;
      default:
        return <Minus className="w-5 h-5 text-gray-500" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Newspaper className="w-6 h-6 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">NewsHub</h1>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setShowPreferences(true)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                title="Preferences"
              >
                <Settings className="w-6 h-6 text-gray-600" />
              </button>
              <button
                onClick={handleSignOut}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                title="Sign out"
              >
                <LogOut className="w-6 h-6 text-gray-600" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="mb-6 rounded-md bg-red-50 p-4">
            <div className="text-sm text-red-700">{error}</div>
          </div>
        )}

        <div className="grid gap-6">
          {articles.map((article) => (
            <article key={article.id} className="bg-white rounded-lg shadow-md p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-semibold flex-1">{article.title}</h3>
                <div className="flex items-center gap-2">
                  {getSentimentIcon(article.sentiment)}
                </div>
              </div>
              
              <p className="text-gray-600 mb-4">{article.summary}</p>
              
              <div className="flex justify-between items-center text-sm text-gray-500">
                <div className="flex items-center gap-4">
                  <span>{article.source}</span>
                  <span>{article.date}</span>
                </div>
                
                <div className="flex gap-3">
                  <button
                    onClick={() => {/* Handle mark as read */}}
                    className="p-2 rounded-full hover:bg-gray-100 transition-colors text-gray-400"
                    title="Mark as read"
                  >
                    <CheckCircle className="w-5 h-5" />
                  </button>
                  
                  <button
                    onClick={() => {/* Handle save */}}
                    className="p-2 rounded-full hover:bg-gray-100 transition-colors text-gray-400"
                    title="Save article"
                  >
                    <BookmarkPlus className="w-5 h-5" />
                  </button>
                  
                  <button
                    onClick={() => {/* Handle share */}}
                    className="p-2 rounded-full hover:bg-gray-100 transition-colors text-gray-400"
                    title="Share article"
                  >
                    <Share2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </main>

      {/* Preferences Panel */}
      {showPreferences && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold">News Preferences</h2>
              <button
                onClick={() => setShowPreferences(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <span className="sr-only">Close</span>
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="space-y-4">
              {preferences.map((pref) => (
                <div key={pref.id} className="flex items-center justify-between">
                  <span className="text-gray-700">{pref.category}</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={pref.isEnabled}
                      onChange={() => {
                        const updatedPreferences = preferences.map((p) =>
                          p.id === pref.id ? { ...p, isEnabled: !p.isEnabled } : p
                        );
                        handleUpdatePreferences(updatedPreferences);
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}